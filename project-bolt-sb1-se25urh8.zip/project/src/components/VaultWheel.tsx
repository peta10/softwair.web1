import { useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { VaultState } from '../types';

interface VaultWheelProps {
  vaultState: VaultState;
}

export default function VaultWheel({ vaultState }: VaultWheelProps) {
  const { isHovered, isUnlocking, isUnlocked, progress } = vaultState;
  const wheelRef = useRef<HTMLDivElement>(null);
  
  // Rotation animation
  useEffect(() => {
    if (!wheelRef.current) return;
    
    if (isUnlocking && progress <= 0.5) {
      // Map progress 0-0.5 to rotation 0-1080 degrees (3 full turns)
      const rotation = (progress / 0.5) * 1080;
      wheelRef.current.style.transform = `rotate(${rotation}deg)`;
    }
  }, [isUnlocking, progress]);
  
  return (
    <div className="relative">
      {/* Outer ring */}
      <motion.div 
        className="relative w-32 h-32 md:w-40 md:h-40 rounded-full border-4 border-[#00e070] flex items-center justify-center"
        initial={{ opacity: 0.7 }}
        animate={{ 
          opacity: isHovered || isUnlocking || isUnlocked ? 1 : 0.7,
          scale: isHovered && !isUnlocking && !isUnlocked ? 1.05 : 1
        }}
        transition={{ duration: 0.3 }}
        style={{
          boxShadow: `0 0 20px rgba(0, 224, 112, ${0.2 + progress * 0.3})`,
        }}
      >
        {/* Inner wheel */}
        <div 
          ref={wheelRef}
          className="w-24 h-24 md:w-32 md:h-32 rounded-full bg-[#0d0d0d] border-2 border-[#00e070] flex items-center justify-center relative"
          style={{
            transition: isUnlocking ? 'none' : 'transform 0.3s ease-out',
          }}
        >
          {/* Biometric scanner */}
          <div 
            className="w-16 h-16 md:w-20 md:h-20 rounded-full flex items-center justify-center relative overflow-hidden"
            style={{
              background: 'linear-gradient(135deg, #0d0d0d, #1a1a1a)',
              boxShadow: 'inset 0 0 10px rgba(0, 0, 0, 0.8)',
            }}
          >
            {/* Scanner light effect */}
            <motion.div 
              className="absolute inset-0 bg-[#00e070] opacity-20"
              initial={{ opacity: 0.1 }}
              animate={{ 
                opacity: isUnlocking ? [0.1, 0.8, 0.1] : isHovered ? 0.3 : 0.1 
              }}
              transition={{ 
                duration: isUnlocking ? 2 : 1,
                repeat: isUnlocking ? 3 : 0,
                ease: "easeInOut"
              }}
            />
            
            {/* Scan line */}
            {(isHovered || isUnlocking) && (
              <motion.div 
                className="absolute h-1 bg-[#00e070] opacity-80 left-0 right-0"
                initial={{ top: 0 }}
                animate={{ top: "100%" }}
                transition={{ 
                  duration: 1.5, 
                  repeat: Infinity,
                  ease: "linear"
                }}
                style={{
                  boxShadow: '0 0 8px rgba(0, 224, 112, 0.8)'
                }}
              />
            )}
            
            {/* Circular indicator */}
            <motion.div 
              className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-transparent border border-[#00e070]"
              initial={{ opacity: 0.5, scale: 0.9 }}
              animate={{ 
                opacity: isHovered || isUnlocking ? 0.8 : 0.5,
                scale: isHovered && !isUnlocking && !isUnlocked ? 1 : 0.9
              }}
              transition={{ duration: 0.3 }}
            />
          </div>
          
          {/* Wheel details - small circles around */}
          {[0, 45, 90, 135, 180, 225, 270, 315].map((angle) => (
            <div 
              key={angle} 
              className="absolute w-2 h-2 rounded-full bg-[#00e070]"
              style={{
                transform: `rotate(${angle}deg) translateY(-58px)`,
                opacity: 0.7 + (progress * 0.3),
              }}
            />
          ))}
        </div>
      </motion.div>
      
      {/* Circle glow effect */}
      <motion.div 
        className="absolute inset-0 rounded-full"
        initial={{ opacity: 0 }}
        animate={{ opacity: isHovered || isUnlocking || isUnlocked ? 0.4 : 0 }}
        style={{
          boxShadow: `0 0 30px 5px rgba(0, 224, 112, ${0.3 + progress * 0.5})`,
        }}
      />
    </div>
  );
}