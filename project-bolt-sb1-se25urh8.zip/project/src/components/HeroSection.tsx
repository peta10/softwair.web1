import { useRef, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import useVaultSequence from '../hooks/useVaultSequence';
import Background from './Background';
import VaultWheel from './VaultWheel';
import VaultDoor from './VaultDoor';
import VaultInterior from './VaultInterior';
import { Volume2, VolumeX } from 'lucide-react';

export default function HeroSection() {
  const { 
    state,
    handleHover,
    startUnlocking,
    navigateToServices,
    isMuted,
    toggleMute
  } = useVaultSequence();
  
  const cursorRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isMobile, setIsMobile] = useState(false);
  
  // Detect mobile device for cursor effects
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    return () => {
      window.removeEventListener('resize', checkMobile);
    };
  }, []);
  
  // Custom cursor effect
  useEffect(() => {
    const container = containerRef.current;
    if (!container || isMobile) return;
    
    const cursor = cursorRef.current;
    if (!cursor) return;
    
    const onMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      // Move the cursor with some lag for nice effect
      cursor.style.transform = `translate(${x}px, ${y}px)`;
    };
    
    container.addEventListener('mousemove', onMouseMove);
    
    return () => {
      container.removeEventListener('mousemove', onMouseMove);
    };
  }, [isMobile]);
  
  // Handle touch cursor effect for mobile
  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isMobile || e.touches.length === 0) return;
    
    const cursor = cursorRef.current;
    if (!cursor) return;
    
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;
    
    const touch = e.touches[0];
    const x = touch.clientX - rect.left;
    const y = touch.clientY - rect.top;
    
    cursor.style.opacity = '1';
    cursor.style.transform = `translate(${x}px, ${y}px)`;
    
    // Hide cursor after a delay
    setTimeout(() => {
      if (cursor) cursor.style.opacity = '0';
    }, 1500);
  };
  
  return (
    <div 
      ref={containerRef}
      className="relative w-full h-screen overflow-hidden cursor-none md:cursor-auto"
      onMouseEnter={() => handleHover(true)}
      onMouseLeave={() => handleHover(false)}
      onTouchStart={() => handleHover(true)}
      onTouchEnd={() => handleHover(false)}
      onTouchMove={handleTouchMove}
    >
      {/* Background elements */}
      <Background progress={state.progress} />
      
      {/* Custom cursor - works on both desktop and mobile */}
      <div 
        ref={cursorRef}
        className="fixed top-0 left-0 w-6 h-6 rounded-full pointer-events-none z-50 transition-opacity duration-700"
        style={{
          background: 'rgba(0, 224, 112, 0.2)',
          transform: 'translate(-50%, -50%)',
          boxShadow: `0 0 ${15 + state.progress * 15}px ${5 + state.progress * 5}px rgba(0, 224, 112, 0.3)`,
          opacity: isMobile ? 0 : 1, // Start hidden on mobile, show on touch
        }}
      />
      
      {/* Main content */}
      <div className="relative z-10 h-full flex flex-col items-center justify-center">
        {/* Header text */}
        <motion.div 
          className="text-center mb-6 md:mb-12"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <h1 className="text-3xl md:text-5xl font-bold text-[#f5f5f5] mb-3">
            Softwair<span className="text-[#00e070]">.io</span>
          </h1>
          <p className="text-[#aaa] text-sm md:text-base tracking-wider max-w-md mx-auto">
            AI-POWERED AUTOMATION SYSTEMS FOR FUTURE-READY BUSINESSES
          </p>
        </motion.div>
        
        {/* Interactive vault */}
        <motion.div 
          className="relative"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.3, ease: "easeOut" }}
        >
          {/* Vault door component */}
          <VaultDoor vaultState={state} />
          
          {/* Vault interior (visible when unlocked) */}
          <VaultInterior 
            vaultState={state} 
            onExplore={navigateToServices} 
          />
          
          {/* Vault wheel (on top of door) */}
          <div 
            className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-10"
            onClick={startUnlocking}
          >
            <VaultWheel vaultState={state} />
          </div>
          
          {/* Instruction text */}
          {!state.isUnlocking && !state.isUnlocked && (
            <motion.div 
              className="absolute left-1/2 -translate-x-1/2 bottom-0 translate-y-16 text-[#f5f5f5] text-sm md:text-base opacity-70 tracking-wider"
              initial={{ opacity: 0 }}
              animate={{ 
                opacity: state.isHovered ? 0.9 : 0.7,
                y: state.isHovered ? -5 : 0 // Subtle float animation when hovered
              }}
              transition={{ duration: 0.3 }}
            >
              {isMobile ? "TAP TO UNLOCK" : "CLICK TO UNLOCK"}
            </motion.div>
          )}
        </motion.div>
      </div>
      
      {/* Sound toggle button with improved animation */}
      <motion.button 
        onClick={toggleMute}
        className="absolute top-4 right-4 z-20 text-[#f5f5f5] opacity-50 hover:opacity-100 transition-opacity"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        animate={{
          scale: isMuted ? 1 : [1, 1.2, 1],
          transition: { 
            scale: { 
              duration: 2, 
              repeat: isMuted ? 0 : Infinity, 
              repeatType: "reverse" 
            }
          }
        }}
      >
        {isMuted ? <VolumeX size={24} /> : <Volume2 size={24} />}
      </motion.button>
    </div>
  );
}