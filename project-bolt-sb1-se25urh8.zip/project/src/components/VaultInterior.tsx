import { motion } from 'framer-motion';
import { ArrowRight, Clock } from 'lucide-react';
import { VaultState } from '../types';

interface VaultInteriorProps {
  vaultState: VaultState;
  onExplore: () => void;
}

export default function VaultInterior({ vaultState, onExplore }: VaultInteriorProps) {
  const { isUnlocked, progress } = vaultState;
  
  // Calculate interior visibility
  const interiorProgress = progress > 0.6 ? (progress - 0.6) / 0.4 : 0;
  
  // Only show when door is opening or open
  if (interiorProgress <= 0) return null;

  // Placeholder function for Time Audit
  const handleTimeAudit = () => {
    alert("Time Audit functionality would be implemented here");
  };
  
  return (
    <motion.div 
      className="absolute inset-0 flex items-center justify-center"
      initial={{ opacity: 0 }}
      animate={{ opacity: interiorProgress }}
      transition={{ duration: 0.3 }}
    >
      {/* Holographic interface */}
      <div className="w-full h-full flex flex-col items-center justify-center relative">
        {/* Enhanced pulsating background */}
        {isUnlocked && (
          <motion.div
            className="absolute inset-0 z-10"
            initial={{ opacity: 0 }}
            animate={{ 
              opacity: [0.2, 0.4, 0.2],
              scale: [1, 1.05, 1]
            }}
            transition={{ 
              duration: 3,
              repeat: Infinity,
              ease: "easeInOut"
            }}
            style={{
              background: `radial-gradient(circle at center, rgba(0, 224, 112, 0.15) 0%, rgba(0, 224, 112, 0.05) 30%, rgba(0, 0, 0, 0) 70%)`,
            }}
          />
        )}
        
        {/* Circuit pattern */}
        <div className="absolute inset-0 flex items-center justify-center z-10">
          {isUnlocked && [...Array(5)].map((_, i) => (
            <motion.div 
              key={i}
              className="absolute rounded-full border border-[#00e070]"
              initial={{ 
                opacity: 0, 
                width: '30%', 
                height: '30%',
              }}
              animate={{ 
                opacity: [(i+1) * 0.15, 0],
                width: ['30%', `${60 + i * 15}%`],
                height: ['30%', `${60 + i * 15}%`],
              }}
              transition={{ 
                duration: 3, 
                repeat: Infinity, 
                delay: i * 0.5,
                ease: "easeOut",
              }}
              style={{
                boxShadow: `0 0 ${5 + i * 3}px rgba(0, 224, 112, 0.3)`,
              }}
            />
          ))}
        </div>
        
        {/* Content container */}
        <div className="relative z-20 flex flex-col items-center justify-center">
          {/* Access granted text with enhanced animation */}
          <motion.div 
            className="text-[#f5f5f5] font-bold text-2xl md:text-4xl mb-8 tracking-wider text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ 
              opacity: isUnlocked ? [0, 1, 0.8, 1] : 0, 
              y: isUnlocked ? [20, 0] : 20,
              textShadow: isUnlocked ? ["0 0 10px rgba(0, 224, 112, 0.5)", "0 0 20px rgba(0, 224, 112, 0.7)", "0 0 10px rgba(0, 224, 112, 0.5)"] : "none"
            }}
            transition={{ 
              duration: 1.5,
              times: [0, 0.7, 0.8, 1],
              ease: "easeOut",
              textShadow: {
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut"
              }
            }}
          >
            ACCESS GRANTED
          </motion.div>
          
          {/* Time Audit button - secondary action */}
          {isUnlocked && (
            <motion.button
              className="mb-4 px-5 py-2 bg-[#1a1a1a] border border-[#00e070] text-[#00e070] font-medium rounded-full flex items-center gap-2 hover:bg-[#222] transition-colors"
              initial={{ opacity: 0, y: 20 }}
              animate={{ 
                opacity: 1, 
                y: 0,
                boxShadow: ["0 0 5px rgba(0, 224, 112, 0.3)", "0 0 10px rgba(0, 224, 112, 0.4)", "0 0 5px rgba(0, 224, 112, 0.3)"]
              }}
              transition={{ 
                duration: 0.5, 
                delay: 0.5,
                boxShadow: {
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }
              }}
              onClick={handleTimeAudit}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Clock size={16} /> Time Audit
            </motion.button>
          )}
          
          {/* CTA button with enhanced animation */}
          {isUnlocked && (
            <motion.button
              className="px-6 py-3 bg-[#00e070] text-black font-medium rounded-full flex items-center gap-2 hover:bg-[#00c060] transition-colors"
              initial={{ opacity: 0, y: 20 }}
              animate={{ 
                opacity: 1, 
                y: 0,
                boxShadow: ["0 0 10px rgba(0, 224, 112, 0.5)", "0 0 20px rgba(0, 224, 112, 0.7)", "0 0 10px rgba(0, 224, 112, 0.5)"]
              }}
              transition={{ 
                duration: 0.5, 
                delay: 0.8,
                boxShadow: {
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }
              }}
              onClick={onExplore}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Explore the System <ArrowRight size={18} />
            </motion.button>
          )}
        </div>
      </div>
    </motion.div>
  );
}