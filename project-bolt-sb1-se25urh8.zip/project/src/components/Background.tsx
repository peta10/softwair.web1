import { useRef, useEffect } from 'react';
import { motion } from 'framer-motion';

interface BackgroundProps {
  progress: number;
}

export default function Background({ progress }: BackgroundProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // Handle grid animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    let animationFrameId: number;
    let particles: { x: number; y: number; size: number; speedX: number; speedY: number; opacity: number; }[] = [];
    
    // Set canvas size
    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      initParticles();
    };
    
    // Initialize particles
    const initParticles = () => {
      particles = [];
      const particleCount = Math.floor(canvas.width * canvas.height / 15000);
      
      for (let i = 0; i < particleCount; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          size: Math.random() * 2 + 1,
          speedX: (Math.random() - 0.5) * 0.2,
          speedY: (Math.random() - 0.5) * 0.2,
          opacity: Math.random() * 0.5 + 0.2
        });
      }
    };
    
    // Draw grid and particles
    const draw = () => {
      if (!ctx || !canvas) return;
      
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Draw grid
      const gridOpacity = Math.min(0.12, 0.05 + 0.07 * progress);
      ctx.strokeStyle = `rgba(0, 224, 112, ${gridOpacity})`;
      ctx.lineWidth = 0.5;
      
      // Vertical lines - adjust grid size with progress for zoom effect
      const baseGridSize = 40;
      const gridSize = baseGridSize * (1 - (progress * 0.15)); // Grid gets smaller as progress increases (zoom effect)
      
      for (let x = 0; x < canvas.width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }
      
      // Horizontal lines
      for (let y = 0; y < canvas.height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }
      
      // Draw particles
      particles.forEach(particle => {
        const particleOpacity = particle.opacity * (0.3 + 0.7 * progress);
        
        ctx.fillStyle = `rgba(0, 224, 112, ${particleOpacity})`;
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size * (1 + progress * 0.5), 0, Math.PI * 2); // Particles grow with progress
        ctx.fill();
        
        // Update particle position - speed increases with progress
        const speedMultiplier = 1 + progress * 0.8;
        particle.x += particle.speedX * speedMultiplier;
        particle.y += particle.speedY * speedMultiplier;
        
        // Wrap around edges
        if (particle.x < 0) particle.x = canvas.width;
        if (particle.x > canvas.width) particle.x = 0;
        if (particle.y < 0) particle.y = canvas.height;
        if (particle.y > canvas.height) particle.y = 0;
      });
      
      animationFrameId = requestAnimationFrame(draw);
    };
    
    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();
    draw();
    
    return () => {
      window.removeEventListener('resize', resizeCanvas);
      cancelAnimationFrame(animationFrameId);
    };
  }, [progress]);
  
  return (
    <div className="absolute inset-0 overflow-hidden">
      {/* Gradient background */}
      <div 
        className="absolute inset-0 bg-gradient-to-b from-[#0d0d0d] to-[#0a0a0a]"
        style={{ opacity: 1 }}
      />
      
      {/* Animated canvas for grid and particles */}
      <motion.canvas 
        ref={canvasRef} 
        className="absolute inset-0"
        animate={{
          scale: 1 + (progress * 0.05), // Subtle zoom effect as progress increases
        }}
        transition={{
          duration: 0.5,
          ease: "easeOut"
        }}
      />
      
      {/* Radial gradient when unlocked */}
      <motion.div 
        className="absolute inset-0 bg-radial-gradient pointer-events-none"
        initial={{ opacity: 0 }}
        animate={{ 
          opacity: progress,
          scale: 1 + (progress * 0.1) // Grow slightly with progress
        }}
        style={{
          background: `radial-gradient(circle at center, rgba(0, 224, 112, 0.1) 0%, rgba(13, 13, 13, 0) 70%)`,
        }}
      />
      
      {/* Additional subtle depth layers */}
      <div 
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `radial-gradient(ellipse at bottom, rgba(0, 224, 112, 0.03) 0%, rgba(0, 0, 0, 0) 70%)`,
          opacity: progress,
        }}
      />
    </div>
  );
}