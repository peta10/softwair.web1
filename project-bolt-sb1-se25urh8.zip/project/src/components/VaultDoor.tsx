import { motion } from 'framer-motion';
import { VaultState } from '../types';

interface VaultDoorProps {
  vaultState: VaultState;
}

export default function VaultDoor({ vaultState }: VaultDoorProps) {
  const { isHovered, isUnlocking, isUnlocked, progress } = vaultState;
  
  // Calculate door opening
  const doorProgress = progress > 0.5 ? (progress - 0.5) / 0.5 : 0;
  const doorOpeningDegree = doorProgress * 110; // Open to 110 degrees max
  
  return (
    <div className="relative w-64 h-64 md:w-80 md:h-80">
      {/* Vault outer frame */}
      <motion.div 
        className="absolute inset-0 rounded-full border-8 border-[#333] bg-gradient-to-br from-[#1a1a1a] to-[#0d0d0d]"
        initial={{ opacity: 0.9 }}
        animate={{ 
          opacity: isHovered || isUnlocking || isUnlocked ? 1 : 0.9,
          scale: isHovered && !isUnlocking && !isUnlocked ? 1.02 : 1
        }}
        transition={{ duration: 0.3 }}
        style={{
          boxShadow: `0 0 30px rgba(0, 0, 0, 0.8), inset 0 0 20px rgba(0, 0, 0, 0.5)`,
          // Hide the entire frame when door is fully open
          opacity: isUnlocked ? 0 : 1,
          transition: 'opacity 0.5s ease',
        }}
      >
        {/* Vault seams and details */}
        {[45, 135, 225, 315].map((angle) => (
          <div 
            key={angle} 
            className="absolute w-full h-0.5 bg-[#444] origin-center"
            style={{
              top: '50%',
              transform: `rotate(${angle}deg)`,
              boxShadow: `0 0 5px rgba(0, 224, 112, ${0.1 + progress * 0.2})`,
            }}
          />
        ))}
        
        {/* Vault door - opens with 3D perspective */}
        <div className="absolute inset-0 rounded-full overflow-hidden" style={{ perspective: '1200px' }}>
          <motion.div 
            className="absolute inset-0 rounded-full bg-gradient-to-br from-[#222] to-[#111] overflow-hidden"
            style={{
              transformOrigin: 'left center',
              transform: `rotateY(${doorOpeningDegree}deg)`,
              boxShadow: doorProgress > 0 
                ? `5px 0 20px rgba(0, 0, 0, 0.8), 0 0 30px rgba(0, 0, 0, 0.6)` 
                : 'none',
              // When fully open, push the door far enough away to not block content
              zIndex: doorProgress > 0.9 ? -10 : 1,
              opacity: doorProgress > 0.95 ? 0 : 1, // Completely hide door when fully open
            }}
          >
            {/* Door thickness - side edge visible during opening */}
            <div 
              className="absolute top-0 bottom-0 left-0 w-3 bg-[#151515]"
              style={{
                opacity: doorProgress > 0 ? 1 : 0,
                boxShadow: 'inset -1px 0 3px rgba(0, 0, 0, 0.5)',
              }}
            />
            
            {/* Door interior facing - only visible when opening */}
            <div 
              className="absolute inset-0 bg-gradient-to-r from-[#111] to-[#181818]"
              style={{
                transformOrigin: 'right center',
                transform: `rotateY(${180}deg)`,
                backfaceVisibility: 'visible',
                opacity: doorProgress > 0.3 ? doorProgress : 0,
              }}
            >
              {/* Interior vault mechanisms - only visible during opening */}
              {[...Array(6)].map((_, i) => (
                <div 
                  key={i}
                  className="absolute rounded-full border border-[#333]"
                  style={{
                    left: '50%',
                    top: '50%',
                    width: `${30 + i * 10}%`,
                    height: `${30 + i * 10}%`,
                    transform: 'translate(-50%, -50%)',
                    opacity: 0.3 + (i * 0.05),
                  }}
                />
              ))}
            </div>
            
            {/* Door front details */}
            <div className="absolute inset-2 rounded-full border border-[#333]" />
            
            {/* Door bolts */}
            {[30, 60, 120, 150, 210, 240, 300, 330].map((angle) => (
              <div 
                key={angle} 
                className="absolute w-3 h-3 bg-[#444] rounded-full"
                style={{
                  left: `calc(50% + ${Math.cos(angle * Math.PI / 180) * 45}%)`,
                  top: `calc(50% + ${Math.sin(angle * Math.PI / 180) * 45}%)`,
                  transform: 'translate(-50%, -50%)',
                  boxShadow: 'inset 0 0 2px rgba(0, 0, 0, 0.8)',
                }}
              />
            ))}
            
            {/* Digital numbers */}
            <div 
              className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-[#00e070] opacity-60 font-mono text-sm rotate-0"
              style={{ opacity: 1 - doorProgress * 2 }} // Fade out as door opens
            >
              {Math.floor(progress * 100).toString().padStart(2, '0')}
            </div>
            
            {/* Seam light effect */}
            <div 
              className="absolute inset-0 rounded-full"
              style={{
                boxShadow: `inset 0 0 ${5 + progress * 15}px rgba(0, 224, 112, ${0.1 + progress * 0.4})`,
                opacity: 0.7,
              }}
            />
          </motion.div>
        </div>
      </motion.div>
      
      {/* Interior light when door is open */}
      {doorProgress > 0 && (
        <motion.div 
          className="absolute inset-0 rounded-full bg-[#00e070]"
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.15 * doorProgress }}
          style={{
            filter: `blur(${20 + doorProgress * 20}px)`,
            opacity: doorProgress > 0.95 ? 0 : 0.15 * doorProgress, // Hide glow when fully open
          }}
        />
      )}
      
      {/* Dynamic shadows that grow as door opens */}
      {doorProgress > 0 && (
        <div 
          className="absolute left-0 top-0 w-full h-full rounded-full"
          style={{
            boxShadow: `inset ${-10 - doorProgress * 30}px 0 ${20 + doorProgress * 30}px rgba(0, 0, 0, ${0.5 + doorProgress * 0.3})`,
            opacity: doorProgress < 0.95 ? doorProgress : 0,
            pointerEvents: 'none',
          }}
        />
      )}
    </div>
  );
}