import { useState, useCallback, useEffect } from 'react';
import { VaultState } from '../types';
import soundBank from '../utils/SoundBank';

export default function useVaultSequence() {
  const [state, setState] = useState<VaultState>({
    isHovered: false,
    isUnlocking: false,
    isUnlocked: false,
    progress: 0,
  });
  
  const [muted, setMuted] = useState(true);
  const [hasTouched, setHasTouched] = useState(false);
  
  // Initialize sounds
  useEffect(() => {
    // We'll keep sounds muted by default until user interaction
    soundBank.setMasterVolume(0);
    
    // Setup touch detection for mobile optimizations
    const handleTouchStart = () => {
      setHasTouched(true);
    };
    
    window.addEventListener('touchstart', handleTouchStart, { once: true });
    
    return () => {
      soundBank.stop('ambient');
      window.removeEventListener('touchstart', handleTouchStart);
    };
  }, []);
  
  const enableSound = useCallback(() => {
    if (muted) {
      setMuted(false);
      soundBank.setMasterVolume(0.7);
      soundBank.play('ambient');
    }
  }, [muted]);
  
  const handleHover = useCallback((isHovered: boolean) => {
    setState(prev => ({ ...prev, isHovered }));
    
    if (isHovered && !state.isUnlocking && !state.isUnlocked) {
      enableSound();
      soundBank.play('hover');
      
      // Trigger subtle haptic feedback on hover for touch devices
      if (hasTouched && navigator.vibrate) {
        try {
          navigator.vibrate(5); // Very subtle vibration
        } catch (e) {
          // Silently fail if vibration is not supported
        }
      }
    }
  }, [state.isUnlocking, state.isUnlocked, enableSound, hasTouched]);
  
  const startUnlocking = useCallback(() => {
    if (state.isUnlocking || state.isUnlocked) return;
    
    enableSound();
    soundBank.play('click');
    
    // Trigger haptic feedback for the click
    if (navigator.vibrate) {
      try {
        navigator.vibrate(15);
      } catch (e) {
        // Silently fail if vibration is not supported
      }
    }
    
    setState(prev => ({ 
      ...prev, 
      isUnlocking: true,
      progress: 0
    }));
    
    // Start the unlock sequence
    setTimeout(() => {
      soundBank.play('unlock');
      
      // Animate progress from 0 to 0.5 over 2.5 seconds
      let start = Date.now();
      const duration = 2500;
      
      const step = () => {
        const elapsed = Date.now() - start;
        const progress = Math.min(0.5, elapsed / duration / 2);
        
        setState(prev => ({ ...prev, progress }));
        
        if (progress < 0.5) {
          requestAnimationFrame(step);
        } else {
          // When wheel rotation is complete, open the door
          soundBank.play('doorOpen');
          
          // Trigger haptic feedback for door opening
          if (navigator.vibrate) {
            try {
              navigator.vibrate([10, 20, 30, 40, 50]);
            } catch (e) {
              // Silently fail if vibration is not supported
            }
          }
          
          // Animate progress from 0.5 to 1 over 3 seconds
          start = Date.now();
          const doorDuration = 2500; // Slightly faster door opening
          
          const doorStep = () => {
            const doorElapsed = Date.now() - start;
            const doorProgress = 0.5 + Math.min(0.5, doorElapsed / doorDuration / 2);
            
            setState(prev => ({ ...prev, progress: doorProgress }));
            
            if (doorProgress < 1) {
              requestAnimationFrame(doorStep);
            } else {
              // When door is fully open
              setState(prev => ({ 
                ...prev, 
                isUnlocking: false, 
                isUnlocked: true,
                progress: 1
              }));
              
              setTimeout(() => {
                soundBank.play('accessGranted');
                
                // Trigger haptic feedback for access granted
                if (navigator.vibrate) {
                  try {
                    navigator.vibrate([20, 30, 20, 30, 40, 80]);
                  } catch (e) {
                    // Silently fail if vibration is not supported
                  }
                }
              }, 500);
            }
          };
          
          requestAnimationFrame(doorStep);
        }
      };
      
      requestAnimationFrame(step);
    }, 300);
  }, [state.isUnlocking, state.isUnlocked, enableSound]);
  
  const resetVault = useCallback(() => {
    setState({
      isHovered: false,
      isUnlocking: false,
      isUnlocked: false,
      progress: 0,
    });
  }, []);
  
  const navigateToServices = useCallback(() => {
    if (state.isUnlocked) {
      // This would navigate to /services in a real app
      console.log("Navigating to /services");
      alert("In a real application, this would navigate to /services");
      
      // Trigger haptic feedback for navigation
      if (navigator.vibrate) {
        try {
          navigator.vibrate(20);
        } catch (e) {
          // Silently fail if vibration is not supported
        }
      }
      
      // For demo purposes, reset the vault after 1 second
      setTimeout(resetVault, 1000);
    }
  }, [state.isUnlocked, resetVault]);
  
  return {
    state,
    handleHover,
    startUnlocking,
    navigateToServices,
    resetVault,
    isMuted: muted,
    toggleMute: () => {
      setMuted(!muted);
      soundBank.setMasterVolume(muted ? 0.7 : 0);
      if (!muted) {
        soundBank.stop('ambient');
      } else {
        soundBank.play('ambient');
      }
    }
  };
}