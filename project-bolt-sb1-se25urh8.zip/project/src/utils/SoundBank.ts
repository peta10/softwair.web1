import { Howl } from 'howler';
import { SoundOptions } from '../types';

class SoundBank {
  private sounds: Map<string, Howl> = new Map();
  private masterVolume: number = 0.7;

  constructor() {
    this.preloadSounds();
  }

  private preloadSounds() {
    this.registerSound('ambient', '/sounds/ambient.mp3', { loop: true, volume: 0.2 });
    this.registerSound('hover', '/sounds/hover.mp3', { volume: 0.3 });
    this.registerSound('click', '/sounds/click.mp3', { volume: 0.5 });
    this.registerSound('unlock', '/sounds/unlock.mp3', { volume: 0.6 });
    this.registerSound('doorOpen', '/sounds/door-open.mp3', { volume: 0.6 });
    
    // Enhanced access granted sound with spatial effects
    this.registerSound('accessGranted', '/sounds/access-granted.mp3', { 
      volume: 0.5,
      onload: (id) => {
        const sound = this.sounds.get('accessGranted');
        if (sound) {
          // Add spatial audio properties for more immersion
          sound.stereo(0); // Center the sound
          sound.pos(0, 0, 0.5); // Position slightly in front of listener
          
          // We can't add actual reverb with Howler alone, but we can
          // simulate some depth by adjusting these properties
          sound.rate(0.98); // Slightly slow down for more dramatic impact
        }
      }
    });
  }

  registerSound(name: string, url: string, options: SoundOptions = {}) {
    if (!url) return;
    
    const sound = new Howl({
      src: [url],
      volume: (options.volume || 0.5) * this.masterVolume,
      loop: options.loop || false,
      preload: true,
      html5: true, // Use HTML5 Audio to help with mobile playback
      sprite: options.sprite,
      onload: options.onload,
    });
    
    this.sounds.set(name, sound);
  }

  play(name: string) {
    const sound = this.sounds.get(name);
    if (sound) {
      // Attempt to trigger haptic feedback if available (supported in iOS Safari)
      this.triggerHapticFeedback(name);
      
      // Play the sound
      const id = sound.play();
      
      // Apply special effects for specific sounds
      if (name === 'unlock' || name === 'doorOpen') {
        sound.fade(0.1, sound.volume(), 300, id); // Fade in for mechanical sounds
      }
      
      if (name === 'accessGranted') {
        // Add a slight stereo pan animation for the access granted sound
        this.animatePan(sound, id);
      }
      
      return sound;
    }
    return null;
  }

  private animatePan(sound: Howl, id: number) {
    // Create a subtle panning effect
    let direction = 1;
    let pan = 0;
    
    const panInterval = setInterval(() => {
      pan += 0.1 * direction;
      
      if (pan > 0.3 || pan < -0.3) {
        direction *= -1;
      }
      
      sound.stereo(pan, id);
      
      // Check if sound is still playing
      if (!sound.playing(id)) {
        clearInterval(panInterval);
      }
    }, 100);
    
    // Clear interval after 2 seconds max
    setTimeout(() => clearInterval(panInterval), 2000);
  }

  private triggerHapticFeedback(soundName: string) {
    // Only trigger haptic feedback if the API is available
    if (!navigator.vibrate) return;
    
    try {
      // Different vibration patterns for different sounds
      if (soundName === 'click') {
        navigator.vibrate(15);
      } else if (soundName === 'unlock') {
        navigator.vibrate([20, 30, 50]);
      } else if (soundName === 'doorOpen') {
        navigator.vibrate([10, 20, 30, 40, 50]);
      } else if (soundName === 'accessGranted') {
        navigator.vibrate([20, 30, 20, 30, 40, 80]);
      }
    } catch (e) {
      // Silently fail if vibration fails
      console.log('Haptic feedback not supported');
    }
  }

  stop(name: string) {
    const sound = this.sounds.get(name);
    if (sound) {
      sound.stop();
    }
  }

  setMasterVolume(volume: number) {
    this.masterVolume = Math.max(0, Math.min(1, volume));
    
    this.sounds.forEach(sound => {
      sound.volume(sound.volume() * (this.masterVolume / 0.7));
    });
  }
}

// Create a singleton instance
const soundBank = new SoundBank();
export default soundBank;