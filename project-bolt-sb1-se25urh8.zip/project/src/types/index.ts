export interface VaultState {
  isHovered: boolean;
  isUnlocking: boolean;
  isUnlocked: boolean;
  progress: number; // 0 to 1
}

export interface SoundOptions {
  volume?: number;
  loop?: boolean;
  sprite?: Record<string, [number, number]>;
  onload?: (id: number) => void;
}