import React from 'react';
import HeroSection from './components/HeroSection';

function App() {
  return (
    <div className="bg-[#0d0d0d] min-h-screen text-white">
      <HeroSection />
    </div>
  );
}

export default App;